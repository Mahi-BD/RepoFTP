﻿Imports System.ComponentModel
Imports System.IO
Imports System.Net
Imports System.Security.Cryptography
Imports System.Text
Imports System.Threading.Tasks
Imports System.Runtime.InteropServices
Imports FluentFTP

Public Class frmMain
    Private configManager As ConfigManager
    Private cancelTokenSource As Threading.CancellationTokenSource
    Private syncInProgress As Boolean = False

    ' Method to parse FTP URL and extract host and port
    Private Sub ParseFtpUrl(serverInput As String, ByRef host As String, ByRef port As Integer)
        Try
            If String.IsNullOrWhiteSpace(serverInput) Then
                host = ""
                port = 21
                Return
            End If

            ' Remove leading/trailing spaces
            serverInput = serverInput.Trim()

            ' If it starts with ftp://, parse as URL
            If serverInput.ToLower().StartsWith("ftp://") Then
                Dim uri As New Uri(serverInput)
                host = uri.Host
                port = If(uri.Port = -1, 21, uri.Port)
            Else
                ' Check if it contains a port (host:port format)
                If serverInput.Contains(":"c) Then
                    Dim parts() As String = serverInput.Split(":"c)
                    If parts.Length = 2 Then
                        host = parts(0).Trim()
                        If Not Integer.TryParse(parts(1).Trim(), port) Then
                            port = 21 ' Default if port parsing fails
                        End If
                    Else
                        host = serverInput
                        port = 21
                    End If
                Else
                    ' Just a hostname or IP
                    host = serverInput
                    port = 21
                End If
            End If

            ' Validate host is not empty
            If String.IsNullOrWhiteSpace(host) Then
                Throw New ArgumentException("Invalid server address")
            End If

        Catch ex As Exception
            ' If parsing fails, try to use as hostname
            host = serverInput
            port = 21
            Console.WriteLine($"URL parsing failed, using as hostname: {ex.Message}")
        End Try
    End Sub

    Public Sub New()
        InitializeComponent()
        Try
            configManager = New ConfigManager()
        Catch ex As Exception
            MessageBox.Show($"Error initializing configuration manager: {ex.Message}", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If configManager IsNot Nothing Then
            LoadConfiguration()
        End If
        UpdateSyncDirectionLabel()
    End Sub

    Private Sub LoadConfiguration()
        Try
            ' Check if configManager is initialized
            If configManager Is Nothing Then
                configManager = New ConfigManager()
            End If

            ' Safely set text values with null checks
            If txtFtpServer IsNot Nothing Then
                txtFtpServer.Text = configManager.GetValue("FTP", "Server", "")
            End If
            If txtFtpUsername IsNot Nothing Then
                txtFtpUsername.Text = configManager.GetValue("FTP", "Username", "")
            End If
            If txtFtpPassword IsNot Nothing Then
                txtFtpPassword.Text = configManager.GetDecryptedValue("FTP", "Password", "")
            End If
            If txtLocalFolder IsNot Nothing Then
                txtLocalFolder.Text = configManager.GetValue("Sync", "LocalFolder", "")
            End If
            If txtRemoteFolder IsNot Nothing Then
                txtRemoteFolder.Text = configManager.GetValue("Sync", "RemoteFolder", "")
            End If

            Dim direction As String = configManager.GetValue("Sync", "Direction", "LocalToRemote")
            If rbLocalToRemote IsNot Nothing Then
                rbLocalToRemote.Checked = (direction = "LocalToRemote")
            End If
            If rbRemoteToLocal IsNot Nothing Then
                rbRemoteToLocal.Checked = (direction = "RemoteToLocal")
            End If
        Catch ex As Exception
            MessageBox.Show($"Error loading configuration: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SaveConfiguration()
        Try
            ' Check if configManager is initialized
            If configManager Is Nothing Then
                configManager = New ConfigManager()
            End If

            ' Safely get text values with null checks
            Dim serverText As String = If(txtFtpServer?.Text, "")
            Dim usernameText As String = If(txtFtpUsername?.Text, "")
            Dim passwordText As String = If(txtFtpPassword?.Text, "")
            Dim localFolderText As String = If(txtLocalFolder?.Text, "")
            Dim remoteFolderText As String = If(txtRemoteFolder?.Text, "")

            configManager.SetValue("FTP", "Server", serverText)
            configManager.SetValue("FTP", "Username", usernameText)
            configManager.SetEncryptedValue("FTP", "Password", passwordText)
            configManager.SetValue("Sync", "LocalFolder", localFolderText)
            configManager.SetValue("Sync", "RemoteFolder", remoteFolderText)

            Dim direction As String = If(rbLocalToRemote?.Checked = True, "LocalToRemote", "RemoteToLocal")
            configManager.SetValue("Sync", "Direction", direction)

            configManager.SaveConfiguration()
        Catch ex As Exception
            MessageBox.Show($"Error saving configuration: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnBrowseLocal_Click(sender As Object, e As EventArgs) Handles btnBrowseLocal.Click
        Using dialog As New FolderBrowserDialog()
            dialog.Description = "Select Local Folder"
            dialog.SelectedPath = txtLocalFolder.Text

            If dialog.ShowDialog() = DialogResult.OK Then
                txtLocalFolder.Text = dialog.SelectedPath
                SaveConfiguration()
            End If
        End Using
    End Sub

    Private Sub btnTestConnection_Click(sender As Object, e As EventArgs) Handles btnTestConnection.Click
        If String.IsNullOrWhiteSpace(txtFtpServer.Text) OrElse
           String.IsNullOrWhiteSpace(txtFtpUsername.Text) Then
            MessageBox.Show("Please enter FTP server and username.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        btnTestConnection.Enabled = False
        lblStatus.Text = "Testing connection..."

        Task.Run(Async Function()
                     Try
                         Dim testResult As Boolean = Await TestFtpConnection()

                         Me.Invoke(Sub()
                                       If testResult Then
                                           lblStatus.Text = "Connection successful!"
                                           lblStatus.ForeColor = Color.Green
                                           MessageBox.Show("FTP connection successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                       Else
                                           lblStatus.Text = "Connection failed!"
                                           lblStatus.ForeColor = Color.Red
                                           MessageBox.Show("FTP connection failed. Please check your credentials.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                       End If
                                       btnTestConnection.Enabled = True
                                   End Sub)
                     Catch ex As Exception
                         Me.Invoke(Sub()
                                       lblStatus.Text = "Connection error!"
                                       lblStatus.ForeColor = Color.Red
                                       MessageBox.Show($"Connection error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                       btnTestConnection.Enabled = True
                                   End Sub)
                     End Try
                 End Function)
    End Sub

    Private Async Function TestFtpConnection() As Task(Of Boolean)
        Try
            Dim host As String = ""
            Dim port As Integer = 21 ' Default FTP port

            ' Parse FTP URL to extract host and port
            ParseFtpUrl(txtFtpServer.Text, host, port)

            Using client As New AsyncFtpClient(host, port, txtFtpUsername.Text, txtFtpPassword.Text)
                client.Config.ConnectTimeout = 10000 ' 10 seconds timeout
                client.Config.DataConnectionType = FtpDataConnectionType.PASV
                Await client.AutoConnect()
                Dim isConnected As Boolean = client.IsConnected
                If isConnected Then
                    Await client.Disconnect()
                End If
                Return isConnected
            End Using
        Catch ex As Exception
            Console.WriteLine($"Connection test error: {ex.Message}")
            Return False
        End Try
    End Function

    Private Sub rbDirection_CheckedChanged(sender As Object, e As EventArgs) Handles rbLocalToRemote.CheckedChanged, rbRemoteToLocal.CheckedChanged
        UpdateSyncDirectionLabel()
        SaveConfiguration()
    End Sub

    Private Sub UpdateSyncDirectionLabel()
        If rbLocalToRemote.Checked Then
            lblSyncDirection.Text = "Local → Remote"
            lblSyncDirection.ForeColor = Color.Blue
        Else
            lblSyncDirection.Text = "Remote → Local"
            lblSyncDirection.ForeColor = Color.DarkGreen
        End If
    End Sub

    Private Sub btnSync_Click(sender As Object, e As EventArgs) Handles btnSync.Click
        If syncInProgress Then
            ' Cancel sync
            If cancelTokenSource IsNot Nothing Then
                cancelTokenSource.Cancel()
            End If
            Return
        End If

        If Not ValidateInputs() Then
            Return
        End If

        SaveConfiguration()
        StartSync()
    End Sub

    Private Function ValidateInputs() As Boolean
        If String.IsNullOrWhiteSpace(txtFtpServer.Text) Then
            MessageBox.Show("Please enter FTP server address." & vbCrLf & vbCrLf &
                          "Examples:" & vbCrLf &
                          "• 192.168.1.100" & vbCrLf &
                          "• ftp.example.com:2121" & vbCrLf &
                          "• ftp://192.168.31.132:2122",
                          "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtFtpServer.Focus()
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtFtpUsername.Text) Then
            MessageBox.Show("Please enter FTP username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            txtFtpUsername.Focus()
            Return False
        End If

        If String.IsNullOrWhiteSpace(txtLocalFolder.Text) Then
            MessageBox.Show("Please select local folder.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            btnBrowseLocal.Focus()
            Return False
        End If

        If Not Directory.Exists(txtLocalFolder.Text) Then
            MessageBox.Show("Selected local folder does not exist.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            btnBrowseLocal.Focus()
            Return False
        End If

        Return True
    End Function

    Private Sub StartSync()
        syncInProgress = True
        btnSync.Text = "Cancel Sync"
        btnSync.BackColor = Color.IndianRed
        progressBar.Value = 0
        progressBar.Visible = True
        lblProgress.Visible = True
        lblProgress.Text = "Preparing sync..."
        lblStatus.Text = "Synchronization in progress..."
        lblStatus.ForeColor = Color.Blue

        cancelTokenSource = New Threading.CancellationTokenSource()

        Task.Run(Async Function()
                     Try
                         If rbLocalToRemote.Checked Then
                             Await SyncLocalToRemote(cancelTokenSource.Token)
                         Else
                             Await SyncRemoteToLocal(cancelTokenSource.Token)
                         End If

                         Me.Invoke(Sub()
                                       lblStatus.Text = "Synchronization completed successfully!"
                                       lblStatus.ForeColor = Color.Green
                                       MessageBox.Show("Synchronization completed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                   End Sub)
                     Catch ex As OperationCanceledException
                         Me.Invoke(Sub()
                                       lblStatus.Text = "Synchronization cancelled."
                                       lblStatus.ForeColor = Color.Orange
                                   End Sub)
                     Catch ex As Exception
                         Me.Invoke(Sub()
                                       lblStatus.Text = "Synchronization failed!"
                                       lblStatus.ForeColor = Color.Red
                                       MessageBox.Show($"Synchronization error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                   End Sub)
                     Finally
                         Me.Invoke(Sub()
                                       syncInProgress = False
                                       btnSync.Text = "Start Sync"
                                       btnSync.BackColor = Color.LimeGreen
                                       progressBar.Visible = False
                                       lblProgress.Visible = False
                                   End Sub)
                     End Try
                 End Function)
    End Sub

    Private Async Function SyncLocalToRemote(cancellationToken As Threading.CancellationToken) As Task
        Dim host As String = ""
        Dim port As Integer = 21

        ' Parse FTP URL to extract host and port
        ParseFtpUrl(txtFtpServer.Text, host, port)

        Using client As New AsyncFtpClient(host, port, txtFtpUsername.Text, txtFtpPassword.Text)
            client.Config.ConnectTimeout = 30000 ' 30 seconds timeout
            client.Config.DataConnectionType = FtpDataConnectionType.PASV
            Await client.AutoConnect(cancellationToken)

            ' Ensure remote directory exists
            If Not String.IsNullOrEmpty(txtRemoteFolder.Text) Then
                Await client.CreateDirectory(txtRemoteFolder.Text, True, cancellationToken)
            End If

            Dim localFiles As String() = Directory.GetFiles(txtLocalFolder.Text, "*", SearchOption.AllDirectories)
            Dim totalFiles As Integer = localFiles.Length

            If totalFiles = 0 Then
                Me.Invoke(Sub()
                              lblProgress.Text = "No files to upload"
                          End Sub)
                Return
            End If

            Dim processedFiles As Integer = 0

            For Each localFile As String In localFiles
                If cancellationToken.IsCancellationRequested Then
                    Throw New OperationCanceledException()
                End If

                Try
                    Dim relativePath As String = Path.GetRelativePath(txtLocalFolder.Text, localFile)
                    Dim remotePath As String

                    If String.IsNullOrEmpty(txtRemoteFolder.Text) Then
                        remotePath = relativePath.Replace("\"c, "/"c)
                    Else
                        remotePath = $"{txtRemoteFolder.Text.TrimEnd("/"c)}/{relativePath.Replace("\"c, "/"c)}"
                    End If

                    Me.Invoke(Sub()
                                  lblProgress.Text = $"Uploading: {Path.GetFileName(localFile)} ({processedFiles + 1}/{totalFiles})"
                                  progressBar.Value = CInt((processedFiles / totalFiles) * 100)
                              End Sub)

                    ' Create remote directory structure if needed
                    Dim remoteDir As String = remotePath.Substring(0, remotePath.LastIndexOf("/"c))
                    If Not String.IsNullOrEmpty(remoteDir) Then
                        Await client.CreateDirectory(remoteDir, True, cancellationToken)
                    End If

                    ' Upload file with FluentFTP (replaces existing files)
                    Await client.UploadFile(localFile, remotePath, FtpRemoteExists.Overwrite, True, token:=cancellationToken)
                    processedFiles += 1
                Catch ex As Exception When Not TypeOf ex Is OperationCanceledException
                    ' Log the error but continue with other files
                    Console.WriteLine($"Error uploading {localFile}: {ex.Message}")
                End Try
            Next

            Await client.Disconnect(cancellationToken)

            Me.Invoke(Sub()
                          progressBar.Value = 100
                          lblProgress.Text = $"Completed: {processedFiles} files uploaded"
                      End Sub)
        End Using
    End Function

    Private Async Function SyncRemoteToLocal(cancellationToken As Threading.CancellationToken) As Task
        Dim host As String = ""
        Dim port As Integer = 21

        ' Parse FTP URL to extract host and port
        ParseFtpUrl(txtFtpServer.Text, host, port)

        Using client As New AsyncFtpClient(host, port, txtFtpUsername.Text, txtFtpPassword.Text)
            client.Config.ConnectTimeout = 30000 ' 30 seconds timeout
            client.Config.DataConnectionType = FtpDataConnectionType.PASV
            Await client.AutoConnect(cancellationToken)

            ' Check if remote directory exists
            Dim remoteDir As String = If(String.IsNullOrEmpty(txtRemoteFolder.Text), "/", txtRemoteFolder.Text)
            If Not Await client.DirectoryExists(remoteDir, cancellationToken) Then
                Throw New DirectoryNotFoundException($"Remote directory '{remoteDir}' does not exist.")
            End If

            ' Get list of remote files
            Dim remoteItems As FtpListItem() = Await client.GetListing(remoteDir, FtpListOption.Recursive, cancellationToken)
            Dim remoteFiles As FtpListItem() = remoteItems.Where(Function(item) item.Type = FtpObjectType.File).ToArray()

            Dim totalFiles As Integer = remoteFiles.Length

            If totalFiles = 0 Then
                Me.Invoke(Sub()
                              lblProgress.Text = "No files to download"
                          End Sub)
                Return
            End If

            Dim processedFiles As Integer = 0

            For Each remoteFile As FtpListItem In remoteFiles
                If cancellationToken.IsCancellationRequested Then
                    Throw New OperationCanceledException()
                End If

                Try
                    Dim relativePath As String = remoteFile.FullName.Replace(remoteDir.TrimEnd("/"c) & "/", "").Replace("/"c, "\"c)
                    Dim localPath As String = Path.Combine(txtLocalFolder.Text, relativePath)

                    Me.Invoke(Sub()
                                  lblProgress.Text = $"Downloading: {Path.GetFileName(remoteFile.Name)} ({processedFiles + 1}/{totalFiles})"
                                  progressBar.Value = CInt((processedFiles / totalFiles) * 100)
                              End Sub)

                    ' Create local directory if it doesn't exist
                    Dim localDir As String = Path.GetDirectoryName(localPath)
                    If Not Directory.Exists(localDir) Then
                        Directory.CreateDirectory(localDir)
                    End If

                    ' Download file with FluentFTP (overwrites existing files)
                    Await client.DownloadFile(localPath, remoteFile.FullName, FtpLocalExists.Overwrite, token:=cancellationToken)
                    processedFiles += 1
                Catch ex As Exception When Not TypeOf ex Is OperationCanceledException
                    ' Log the error but continue with other files
                    Console.WriteLine($"Error downloading {remoteFile.FullName}: {ex.Message}")
                End Try
            Next

            Await client.Disconnect(cancellationToken)

            Me.Invoke(Sub()
                          progressBar.Value = 100
                          lblProgress.Text = $"Completed: {processedFiles} files downloaded"
                      End Sub)
        End Using
    End Function

    Private Sub frmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If syncInProgress Then
            Dim result As DialogResult = MessageBox.Show("Synchronization is in progress. Do you want to cancel and exit?",
                                                        "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.No Then
                e.Cancel = True
                Return
            End If

            If cancelTokenSource IsNot Nothing Then
                cancelTokenSource.Cancel()
            End If
        End If

        SaveConfiguration()
    End Sub

    Private Sub txtConfiguration_TextChanged(sender As Object, e As EventArgs) Handles txtFtpServer.TextChanged, txtFtpUsername.TextChanged, txtFtpPassword.TextChanged, txtLocalFolder.TextChanged, txtRemoteFolder.TextChanged
        ' Auto-save configuration when text changes (with a small delay to avoid excessive saves)
        ' Only save if the form is fully loaded and configManager is initialized
        If configManager Is Nothing OrElse Not Me.IsHandleCreated Then
            Return
        End If

        Static saveTimer As Timer
        If saveTimer IsNot Nothing Then
            saveTimer.Stop()
            saveTimer.Dispose()
        End If

        saveTimer = New Timer()
        saveTimer.Interval = 1000 ' 1 second delay
        AddHandler saveTimer.Tick, Sub()
                                       saveTimer.Stop()
                                       saveTimer.Dispose()
                                       SaveConfiguration()
                                   End Sub
        saveTimer.Start()
    End Sub
End Class
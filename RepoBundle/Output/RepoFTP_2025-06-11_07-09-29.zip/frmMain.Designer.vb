﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.grpFtpSettings = New System.Windows.Forms.GroupBox()
        Me.lblServerHint = New System.Windows.Forms.Label()
        Me.btnTestConnection = New System.Windows.Forms.Button()
        Me.txtFtpPassword = New System.Windows.Forms.TextBox()
        Me.txtFtpUsername = New System.Windows.Forms.TextBox()
        Me.txtFtpServer = New System.Windows.Forms.TextBox()
        Me.lblFtpPassword = New System.Windows.Forms.Label()
        Me.lblFtpUsername = New System.Windows.Forms.Label()
        Me.lblFtpServer = New System.Windows.Forms.Label()
        Me.grpSyncSettings = New System.Windows.Forms.GroupBox()
        Me.lblSyncDirection = New System.Windows.Forms.Label()
        Me.grpDirection = New System.Windows.Forms.GroupBox()
        Me.rbRemoteToLocal = New System.Windows.Forms.RadioButton()
        Me.rbLocalToRemote = New System.Windows.Forms.RadioButton()
        Me.btnBrowseLocal = New System.Windows.Forms.Button()
        Me.txtRemoteFolder = New System.Windows.Forms.TextBox()
        Me.txtLocalFolder = New System.Windows.Forms.TextBox()
        Me.lblRemoteFolder = New System.Windows.Forms.Label()
        Me.lblLocalFolder = New System.Windows.Forms.Label()
        Me.grpSync = New System.Windows.Forms.GroupBox()
        Me.lblProgress = New System.Windows.Forms.Label()
        Me.progressBar = New System.Windows.Forms.ProgressBar()
        Me.btnSync = New System.Windows.Forms.Button()
        Me.btnViewLogs = New System.Windows.Forms.Button()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.statusStrip = New System.Windows.Forms.StatusStrip()
        Me.toolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel()
        Me.folderBrowserDialog = New System.Windows.Forms.FolderBrowserDialog()
        Me.toolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.grpFtpSettings.SuspendLayout()
        Me.grpSyncSettings.SuspendLayout()
        Me.grpDirection.SuspendLayout()
        Me.grpSync.SuspendLayout()
        Me.statusStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpFtpSettings
        '
        Me.grpFtpSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpFtpSettings.Controls.Add(Me.lblServerHint)
        Me.grpFtpSettings.Controls.Add(Me.btnTestConnection)
        Me.grpFtpSettings.Controls.Add(Me.txtFtpPassword)
        Me.grpFtpSettings.Controls.Add(Me.txtFtpUsername)
        Me.grpFtpSettings.Controls.Add(Me.txtFtpServer)
        Me.grpFtpSettings.Controls.Add(Me.lblFtpPassword)
        Me.grpFtpSettings.Controls.Add(Me.lblFtpUsername)
        Me.grpFtpSettings.Controls.Add(Me.lblFtpServer)
        Me.grpFtpSettings.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpFtpSettings.Location = New System.Drawing.Point(12, 12)
        Me.grpFtpSettings.Name = "grpFtpSettings"
        Me.grpFtpSettings.Size = New System.Drawing.Size(560, 150)
        Me.grpFtpSettings.TabIndex = 0
        Me.grpFtpSettings.TabStop = False
        Me.grpFtpSettings.Text = "FTP Connection Settings"
        '
        'lblServerHint
        '
        Me.lblServerHint.AutoSize = True
        Me.lblServerHint.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.lblServerHint.ForeColor = System.Drawing.Color.Gray
        Me.lblServerHint.Location = New System.Drawing.Point(90, 53)
        Me.lblServerHint.Name = "lblServerHint"
        Me.lblServerHint.Size = New System.Drawing.Size(297, 13)
        Me.lblServerHint.TabIndex = 7
        Me.lblServerHint.Text = "Examples: 192.168.1.100, server.com:2121, ftp://host:port"
        '
        'btnTestConnection
        '
        Me.btnTestConnection.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnTestConnection.BackColor = System.Drawing.Color.SteelBlue
        Me.btnTestConnection.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnTestConnection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnTestConnection.ForeColor = System.Drawing.Color.White
        Me.btnTestConnection.Location = New System.Drawing.Point(440, 105)
        Me.btnTestConnection.Name = "btnTestConnection"
        Me.btnTestConnection.Size = New System.Drawing.Size(110, 30)
        Me.btnTestConnection.TabIndex = 6
        Me.btnTestConnection.Text = "Test Connection"
        Me.toolTip.SetToolTip(Me.btnTestConnection, "Test the FTP connection with current settings")
        Me.btnTestConnection.UseVisualStyleBackColor = False
        '
        'txtFtpPassword
        '
        Me.txtFtpPassword.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFtpPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtFtpPassword.Location = New System.Drawing.Point(90, 110)
        Me.txtFtpPassword.Name = "txtFtpPassword"
        Me.txtFtpPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtFtpPassword.Size = New System.Drawing.Size(330, 21)
        Me.txtFtpPassword.TabIndex = 5
        Me.toolTip.SetToolTip(Me.txtFtpPassword, "FTP password (stored encrypted)")
        '
        'txtFtpUsername
        '
        Me.txtFtpUsername.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFtpUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtFtpUsername.Location = New System.Drawing.Point(90, 80)
        Me.txtFtpUsername.Name = "txtFtpUsername"
        Me.txtFtpUsername.Size = New System.Drawing.Size(460, 21)
        Me.txtFtpUsername.TabIndex = 4
        Me.toolTip.SetToolTip(Me.txtFtpUsername, "FTP username")
        '
        'txtFtpServer
        '
        Me.txtFtpServer.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFtpServer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtFtpServer.Location = New System.Drawing.Point(90, 30)
        Me.txtFtpServer.Name = "txtFtpServer"
        Me.txtFtpServer.Size = New System.Drawing.Size(460, 21)
        Me.txtFtpServer.TabIndex = 3
        Me.toolTip.SetToolTip(Me.txtFtpServer, "FTP server address. Supports: hostname, IP:port, or ftp://server:port")
        '
        'lblFtpPassword
        '
        Me.lblFtpPassword.AutoSize = True
        Me.lblFtpPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFtpPassword.Location = New System.Drawing.Point(15, 113)
        Me.lblFtpPassword.Name = "lblFtpPassword"
        Me.lblFtpPassword.Size = New System.Drawing.Size(61, 15)
        Me.lblFtpPassword.TabIndex = 2
        Me.lblFtpPassword.Text = "Password:"
        '
        'lblFtpUsername
        '
        Me.lblFtpUsername.AutoSize = True
        Me.lblFtpUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFtpUsername.Location = New System.Drawing.Point(15, 83)
        Me.lblFtpUsername.Name = "lblFtpUsername"
        Me.lblFtpUsername.Size = New System.Drawing.Size(68, 15)
        Me.lblFtpUsername.TabIndex = 1
        Me.lblFtpUsername.Text = "Username:"
        '
        'lblFtpServer
        '
        Me.lblFtpServer.AutoSize = True
        Me.lblFtpServer.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblFtpServer.Location = New System.Drawing.Point(15, 33)
        Me.lblFtpServer.Name = "lblFtpServer"
        Me.lblFtpServer.Size = New System.Drawing.Size(44, 15)
        Me.lblFtpServer.TabIndex = 0
        Me.lblFtpServer.Text = "Server:"
        '
        'grpSyncSettings
        '
        Me.grpSyncSettings.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpSyncSettings.Controls.Add(Me.lblSyncDirection)
        Me.grpSyncSettings.Controls.Add(Me.grpDirection)
        Me.grpSyncSettings.Controls.Add(Me.btnBrowseLocal)
        Me.grpSyncSettings.Controls.Add(Me.txtRemoteFolder)
        Me.grpSyncSettings.Controls.Add(Me.txtLocalFolder)
        Me.grpSyncSettings.Controls.Add(Me.lblRemoteFolder)
        Me.grpSyncSettings.Controls.Add(Me.lblLocalFolder)
        Me.grpSyncSettings.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpSyncSettings.Location = New System.Drawing.Point(12, 175)
        Me.grpSyncSettings.Name = "grpSyncSettings"
        Me.grpSyncSettings.Size = New System.Drawing.Size(560, 180)
        Me.grpSyncSettings.TabIndex = 1
        Me.grpSyncSettings.TabStop = False
        Me.grpSyncSettings.Text = "Synchronization Settings"
        '
        'lblSyncDirection
        '
        Me.lblSyncDirection.AutoSize = True
        Me.lblSyncDirection.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblSyncDirection.ForeColor = System.Drawing.Color.Blue
        Me.lblSyncDirection.Location = New System.Drawing.Point(200, 145)
        Me.lblSyncDirection.Name = "lblSyncDirection"
        Me.lblSyncDirection.Size = New System.Drawing.Size(127, 20)
        Me.lblSyncDirection.TabIndex = 6
        Me.lblSyncDirection.Text = "Local → Remote"
        '
        'grpDirection
        '
        Me.grpDirection.Controls.Add(Me.rbRemoteToLocal)
        Me.grpDirection.Controls.Add(Me.rbLocalToRemote)
        Me.grpDirection.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.grpDirection.Location = New System.Drawing.Point(15, 95)
        Me.grpDirection.Name = "grpDirection"
        Me.grpDirection.Size = New System.Drawing.Size(535, 40)
        Me.grpDirection.TabIndex = 5
        Me.grpDirection.TabStop = False
        Me.grpDirection.Text = "Sync Direction"
        '
        'rbRemoteToLocal
        '
        Me.rbRemoteToLocal.AutoSize = True
        Me.rbRemoteToLocal.Location = New System.Drawing.Point(200, 15)
        Me.rbRemoteToLocal.Name = "rbRemoteToLocal"
        Me.rbRemoteToLocal.Size = New System.Drawing.Size(118, 19)
        Me.rbRemoteToLocal.TabIndex = 1
        Me.rbRemoteToLocal.Text = "Remote to Local"
        Me.rbRemoteToLocal.UseVisualStyleBackColor = True
        '
        'rbLocalToRemote
        '
        Me.rbLocalToRemote.AutoSize = True
        Me.rbLocalToRemote.Checked = True
        Me.rbLocalToRemote.Location = New System.Drawing.Point(15, 15)
        Me.rbLocalToRemote.Name = "rbLocalToRemote"
        Me.rbLocalToRemote.Size = New System.Drawing.Size(118, 19)
        Me.rbLocalToRemote.TabIndex = 0
        Me.rbLocalToRemote.TabStop = True
        Me.rbLocalToRemote.Text = "Local to Remote"
        Me.rbLocalToRemote.UseVisualStyleBackColor = True
        '
        'btnBrowseLocal
        '
        Me.btnBrowseLocal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBrowseLocal.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.btnBrowseLocal.Location = New System.Drawing.Point(500, 30)
        Me.btnBrowseLocal.Name = "btnBrowseLocal"
        Me.btnBrowseLocal.Size = New System.Drawing.Size(50, 21)
        Me.btnBrowseLocal.TabIndex = 4
        Me.btnBrowseLocal.Text = "..."
        Me.toolTip.SetToolTip(Me.btnBrowseLocal, "Browse for local folder")
        Me.btnBrowseLocal.UseVisualStyleBackColor = True
        '
        'txtRemoteFolder
        '
        Me.txtRemoteFolder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtRemoteFolder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtRemoteFolder.Location = New System.Drawing.Point(120, 60)
        Me.txtRemoteFolder.Name = "txtRemoteFolder"
        Me.txtRemoteFolder.Size = New System.Drawing.Size(430, 21)
        Me.txtRemoteFolder.TabIndex = 3
        Me.toolTip.SetToolTip(Me.txtRemoteFolder, "Remote FTP folder path (leave empty for root)")
        '
        'txtLocalFolder
        '
        Me.txtLocalFolder.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLocalFolder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtLocalFolder.Location = New System.Drawing.Point(120, 30)
        Me.txtLocalFolder.Name = "txtLocalFolder"
        Me.txtLocalFolder.ReadOnly = True
        Me.txtLocalFolder.Size = New System.Drawing.Size(370, 21)
        Me.txtLocalFolder.TabIndex = 2
        Me.toolTip.SetToolTip(Me.txtLocalFolder, "Local folder path for synchronization")
        '
        'lblRemoteFolder
        '
        Me.lblRemoteFolder.AutoSize = True
        Me.lblRemoteFolder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblRemoteFolder.Location = New System.Drawing.Point(15, 63)
        Me.lblRemoteFolder.Name = "lblRemoteFolder"
        Me.lblRemoteFolder.Size = New System.Drawing.Size(91, 15)
        Me.lblRemoteFolder.TabIndex = 1
        Me.lblRemoteFolder.Text = "Remote Folder:"
        '
        'lblLocalFolder
        '
        Me.lblLocalFolder.AutoSize = True
        Me.lblLocalFolder.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblLocalFolder.Location = New System.Drawing.Point(15, 33)
        Me.lblLocalFolder.Name = "lblLocalFolder"
        Me.lblLocalFolder.Size = New System.Drawing.Size(78, 15)
        Me.lblLocalFolder.TabIndex = 0
        Me.lblLocalFolder.Text = "Local Folder:"
        '
        'grpSync
        '
        Me.grpSync.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grpSync.Controls.Add(Me.lblProgress)
        Me.grpSync.Controls.Add(Me.progressBar)
        Me.grpSync.Controls.Add(Me.btnSync)
        Me.grpSync.Controls.Add(Me.btnViewLogs)
        Me.grpSync.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.grpSync.Location = New System.Drawing.Point(12, 370)
        Me.grpSync.Name = "grpSync"
        Me.grpSync.Size = New System.Drawing.Size(560, 120)
        Me.grpSync.TabIndex = 2
        Me.grpSync.TabStop = False
        Me.grpSync.Text = "Synchronization Control"
        '
        'lblProgress
        '
        Me.lblProgress.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblProgress.Location = New System.Drawing.Point(15, 55)
        Me.lblProgress.Name = "lblProgress"
        Me.lblProgress.Size = New System.Drawing.Size(535, 15)
        Me.lblProgress.TabIndex = 2
        Me.lblProgress.Text = "Ready to sync..."
        Me.lblProgress.Visible = False
        '
        'progressBar
        '
        Me.progressBar.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.progressBar.Location = New System.Drawing.Point(15, 75)
        Me.progressBar.Name = "progressBar"
        Me.progressBar.Size = New System.Drawing.Size(535, 25)
        Me.progressBar.TabIndex = 1
        Me.progressBar.Visible = False
        '
        'btnViewLogs
        '
        Me.btnViewLogs.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnViewLogs.BackColor = System.Drawing.Color.DarkSlateGray
        Me.btnViewLogs.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnViewLogs.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnViewLogs.ForeColor = System.Drawing.Color.White
        Me.btnViewLogs.Location = New System.Drawing.Point(15, 20)
        Me.btnViewLogs.Name = "btnViewLogs"
        Me.btnViewLogs.Size = New System.Drawing.Size(100, 40)
        Me.btnViewLogs.TabIndex = 3
        Me.btnViewLogs.Text = "View Logs"
        Me.toolTip.SetToolTip(Me.btnViewLogs, "Open log viewer to diagnose connection issues")
        Me.btnViewLogs.UseVisualStyleBackColor = False
        '
        'btnSync
        '
        Me.btnSync.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSync.BackColor = System.Drawing.Color.LimeGreen
        Me.btnSync.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSync.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.btnSync.ForeColor = System.Drawing.Color.White
        Me.btnSync.Location = New System.Drawing.Point(430, 20)
        Me.btnSync.Name = "btnSync"
        Me.btnSync.Size = New System.Drawing.Size(120, 40)
        Me.btnSync.TabIndex = 0
        Me.btnSync.Text = "Start Sync"
        Me.toolTip.SetToolTip(Me.btnSync, "Start synchronization process")
        Me.btnSync.UseVisualStyleBackColor = False
        '
        'lblStatus
        '
        Me.lblStatus.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lblStatus.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.lblStatus.Location = New System.Drawing.Point(15, 500)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(557, 20)
        Me.lblStatus.TabIndex = 3
        Me.lblStatus.Text = "Ready"
        '
        'statusStrip
        '
        Me.statusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.toolStripStatusLabel})
        Me.statusStrip.Location = New System.Drawing.Point(0, 528)
        Me.statusStrip.Name = "statusStrip"
        Me.statusStrip.Size = New System.Drawing.Size(584, 22)
        Me.statusStrip.TabIndex = 4
        Me.statusStrip.Text = "StatusStrip1"
        '
        'toolStripStatusLabel
        '
        Me.toolStripStatusLabel.Name = "toolStripStatusLabel"
        Me.toolStripStatusLabel.Size = New System.Drawing.Size(182, 17)
        Me.toolStripStatusLabel.Text = "FTP Sync Application v1.0 - Ready"
        '
        'folderBrowserDialog
        '
        Me.folderBrowserDialog.Description = "Select Local Folder for Synchronization"
        '
        'toolTip
        '
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(584, 550)
        Me.Controls.Add(Me.statusStrip)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.grpSync)
        Me.Controls.Add(Me.grpSyncSettings)
        Me.Controls.Add(Me.grpFtpSettings)
        Me.MinimumSize = New System.Drawing.Size(600, 590)
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FTP Folder Synchronizer"
        Me.grpFtpSettings.ResumeLayout(False)
        Me.grpFtpSettings.PerformLayout()
        Me.grpSyncSettings.ResumeLayout(False)
        Me.grpSyncSettings.PerformLayout()
        Me.grpDirection.ResumeLayout(False)
        Me.grpDirection.PerformLayout()
        Me.grpSync.ResumeLayout(False)
        Me.statusStrip.ResumeLayout(False)
        Me.statusStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents grpFtpSettings As GroupBox
    Friend WithEvents lblServerHint As Label
    Friend WithEvents btnTestConnection As Button
    Friend WithEvents txtFtpPassword As TextBox
    Friend WithEvents txtFtpUsername As TextBox
    Friend WithEvents txtFtpServer As TextBox
    Friend WithEvents lblFtpPassword As Label
    Friend WithEvents lblFtpUsername As Label
    Friend WithEvents lblFtpServer As Label
    Friend WithEvents grpSyncSettings As GroupBox
    Friend WithEvents lblSyncDirection As Label
    Friend WithEvents grpDirection As GroupBox
    Friend WithEvents rbRemoteToLocal As RadioButton
    Friend WithEvents rbLocalToRemote As RadioButton
    Friend WithEvents btnBrowseLocal As Button
    Friend WithEvents txtRemoteFolder As TextBox
    Friend WithEvents txtLocalFolder As TextBox
    Friend WithEvents lblRemoteFolder As Label
    Friend WithEvents lblLocalFolder As Label
    Friend WithEvents grpSync As GroupBox
    Friend WithEvents lblProgress As Label
    Friend WithEvents progressBar As ProgressBar
    Friend WithEvents btnViewLogs As Button
    Friend WithEvents btnSync As Button
    Friend WithEvents lblStatus As Label
    Friend WithEvents statusStrip As StatusStrip
    Friend WithEvents toolStripStatusLabel As ToolStripStatusLabel
    Friend WithEvents folderBrowserDialog As FolderBrowserDialog
    Friend WithEvents toolTip As ToolTip
End Class
﻿Imports System.ComponentModel
Imports System.IO
Imports System.Net
Imports System.Security.Cryptography
Imports System.Text
Imports System.Threading.Tasks
Imports System.Runtime.InteropServices
Imports FluentFTP
Imports FluentFTP.Exceptions

Public Class frmMain
    Private configManager As ConfigManager
    Private cancelTokenSource As Threading.CancellationTokenSource
    Private syncInProgress As Boolean = False
    Private logger As Logger = Logger.Instance
    Private isFormLoading As Boolean = True

    Public Sub New()
        InitializeComponent()
        Try
            logger.Info("Application starting...")
            configManager = New ConfigManager()
            logger.Info("ConfigManager initialized successfully")
        Catch ex As Exception
            logger.Critical("Error initializing application", ex)
            MessageBox.Show($"Error initializing application: {ex.Message}", "Initialization Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        logger.Info("Form loading...")
        isFormLoading = True ' Prevent auto-save during loading

        If configManager IsNot Nothing Then
            LoadConfiguration()
        End If
        UpdateSyncDirectionLabel()

        ' Clean up old log files on startup
        logger.ClearOldLogs(7) ' Keep logs for 7 days

        isFormLoading = False ' Now allow auto-save
        logger.Info("Application loaded successfully")
    End Sub

    Private Sub LoadConfiguration()
        Try
            logger.Debug("Loading configuration...")
            ' Check if configManager is initialized
            If configManager Is Nothing Then
                configManager = New ConfigManager()
                logger.Warning("ConfigManager was null, created new instance")
            End If

            ' Safely set text values with null checks
            If txtFtpServer IsNot Nothing Then
                Dim serverValue As String = configManager.GetValue("FTP", "Server", "")
                txtFtpServer.Text = serverValue
                logger.Debug($"Loaded FTP Server: {If(String.IsNullOrEmpty(serverValue), "(empty)", serverValue)}")
            End If
            If txtFtpUsername IsNot Nothing Then
                Dim usernameValue As String = configManager.GetValue("FTP", "Username", "")
                txtFtpUsername.Text = usernameValue
                logger.Debug($"Loaded FTP Username: {If(String.IsNullOrEmpty(usernameValue), "(empty)", usernameValue)}")
            End If
            If txtFtpPassword IsNot Nothing Then
                Dim passwordValue As String = configManager.GetDecryptedValue("FTP", "Password", "")
                txtFtpPassword.Text = passwordValue
                logger.Debug($"Loaded FTP Password: {If(String.IsNullOrEmpty(passwordValue), "(empty)", "***")}")
            End If
            If txtLocalFolder IsNot Nothing Then
                Dim localFolderValue As String = configManager.GetValue("Sync", "LocalFolder", "")
                txtLocalFolder.Text = localFolderValue
                logger.Debug($"Loaded Local Folder: {If(String.IsNullOrEmpty(localFolderValue), "(empty)", localFolderValue)}")
            End If
            If txtRemoteFolder IsNot Nothing Then
                Dim remoteFolderValue As String = configManager.GetValue("Sync", "RemoteFolder", "")
                txtRemoteFolder.Text = remoteFolderValue
                logger.Debug($"Loaded Remote Folder: {If(String.IsNullOrEmpty(remoteFolderValue), "(empty)", remoteFolderValue)}")
            End If

            Dim direction As String = configManager.GetValue("Sync", "Direction", "LocalToRemote")
            If rbLocalToRemote IsNot Nothing Then
                rbLocalToRemote.Checked = (direction = "LocalToRemote")
            End If
            If rbRemoteToLocal IsNot Nothing Then
                rbRemoteToLocal.Checked = (direction = "RemoteToLocal")
            End If

            logger.Debug($"Loaded Sync Direction: {direction}")
            logger.Info("Configuration loaded successfully")
        Catch ex As Exception
            logger.Error("Error loading configuration", ex)
            MessageBox.Show($"Error loading configuration: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SaveConfiguration()
        Try
            logger.Debug("Saving configuration...")
            ' Check if configManager is initialized
            If configManager Is Nothing Then
                configManager = New ConfigManager()
                logger.Warning("ConfigManager was null, created new instance")
            End If

            ' Safely get text values with null checks
            Dim serverText As String = If(txtFtpServer?.Text, "")
            Dim usernameText As String = If(txtFtpUsername?.Text, "")
            Dim passwordText As String = If(txtFtpPassword?.Text, "")
            Dim localFolderText As String = If(txtLocalFolder?.Text, "")
            Dim remoteFolderText As String = If(txtRemoteFolder?.Text, "")

            configManager.SetValue("FTP", "Server", serverText)
            configManager.SetValue("FTP", "Username", usernameText)
            configManager.SetEncryptedValue("FTP", "Password", passwordText)
            configManager.SetValue("Sync", "LocalFolder", localFolderText)
            configManager.SetValue("Sync", "RemoteFolder", remoteFolderText)

            Dim direction As String = If(rbLocalToRemote?.Checked = True, "LocalToRemote", "RemoteToLocal")
            configManager.SetValue("Sync", "Direction", direction)

            configManager.SaveConfiguration()
            logger.Info("Configuration saved successfully")
        Catch ex As Exception
            logger.Error("Error saving configuration", ex)
            MessageBox.Show($"Error saving configuration: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnBrowseLocal_Click(sender As Object, e As EventArgs) Handles btnBrowseLocal.Click
        Using dialog As New FolderBrowserDialog()
            dialog.Description = "Select Local Folder"
            If txtLocalFolder IsNot Nothing Then
                dialog.SelectedPath = txtLocalFolder.Text
            End If

            If dialog.ShowDialog() = DialogResult.OK Then
                If txtLocalFolder IsNot Nothing Then
                    txtLocalFolder.Text = dialog.SelectedPath
                    logger.Info($"User selected local folder: {dialog.SelectedPath}")
                    ' Save immediately when user selects folder (not during loading)
                    SaveConfiguration()
                End If
            End If
        End Using
    End Sub

    Private Sub btnTestConnection_Click(sender As Object, e As EventArgs) Handles btnTestConnection.Click
        Dim serverText As String = If(txtFtpServer?.Text, "")
        Dim usernameText As String = If(txtFtpUsername?.Text, "")

        If String.IsNullOrWhiteSpace(serverText) OrElse String.IsNullOrWhiteSpace(usernameText) Then
            logger.Warning("Test connection attempted with missing server or username")
            MessageBox.Show("Please enter FTP server and username.", "Missing Information", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        logger.Info("User initiated FTP connection test")
        If btnTestConnection IsNot Nothing Then
            btnTestConnection.Enabled = False
        End If
        If lblStatus IsNot Nothing Then
            lblStatus.Text = "Testing connection..."
        End If

        Task.Run(Async Function()
                     Try
                         Dim testResult As Boolean = Await TestFtpConnection()

                         Me.Invoke(Sub()
                                       If testResult Then
                                           If lblStatus IsNot Nothing Then
                                               lblStatus.Text = "Connection successful!"
                                               lblStatus.ForeColor = Color.Green
                                           End If
                                           logger.Info("FTP connection test successful - User notified")
                                           MessageBox.Show("FTP connection successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                       Else
                                           If lblStatus IsNot Nothing Then
                                               lblStatus.Text = "Connection failed!"
                                               lblStatus.ForeColor = Color.Red
                                           End If
                                           logger.Warning("FTP connection test failed - User notified")
                                           MessageBox.Show("FTP connection failed. Please check your credentials and view logs for details.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                       End If
                                       If btnTestConnection IsNot Nothing Then
                                           btnTestConnection.Enabled = True
                                       End If
                                   End Sub)
                     Catch ex As Exception
                         logger.Error("Unexpected error during connection test", ex)
                         Me.Invoke(Sub()
                                       If lblStatus IsNot Nothing Then
                                           lblStatus.Text = "Connection error!"
                                           lblStatus.ForeColor = Color.Red
                                       End If
                                       MessageBox.Show($"Connection error: {ex.Message}" & vbCrLf & vbCrLf & "Check logs for detailed information.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                       If btnTestConnection IsNot Nothing Then
                                           btnTestConnection.Enabled = True
                                       End If
                                   End Sub)
                     End Try
                 End Function)
    End Sub

    Private Sub btnViewLogs_Click(sender As Object, e As EventArgs) Handles btnViewLogs.Click
        Try
            logger.Info("User opened log viewer")

            ' Get recent log entries
            Dim recentLogs As String() = logger.GetRecentLogs(50)

            If recentLogs.Length > 0 Then
                Dim logText As String = String.Join(Environment.NewLine, recentLogs)

                ' Create a simple form to display logs
                Dim logForm As New Form()
                logForm.Text = "FTP Sync - Log Viewer"
                logForm.Size = New Size(800, 600)
                logForm.StartPosition = FormStartPosition.CenterParent
                logForm.ShowIcon = False

                Dim txtLog As New TextBox()
                txtLog.Multiline = True
                txtLog.ReadOnly = True
                txtLog.ScrollBars = ScrollBars.Both
                txtLog.Font = New Font("Consolas", 9)
                txtLog.Dock = DockStyle.Fill
                txtLog.Text = logText
                txtLog.WordWrap = False

                Dim panel As New Panel()
                panel.Dock = DockStyle.Bottom
                panel.Height = 40

                Dim btnClose As New Button()
                btnClose.Text = "Close"
                btnClose.Size = New Size(75, 23)
                btnClose.Anchor = AnchorStyles.Bottom Or AnchorStyles.Right
                btnClose.Location = New Point(logForm.Width - 90, 8)
                AddHandler btnClose.Click, Sub() logForm.Close()

                Dim lblPath As New Label()
                lblPath.Text = $"Log file: {logger.GetLogFilePath()}"
                lblPath.Dock = DockStyle.Left
                lblPath.TextAlign = ContentAlignment.MiddleLeft
                lblPath.AutoSize = False
                lblPath.Width = 600

                panel.Controls.Add(btnClose)
                panel.Controls.Add(lblPath)
                logForm.Controls.Add(txtLog)
                logForm.Controls.Add(panel)

                ' Auto-scroll to bottom
                txtLog.SelectionStart = txtLog.Text.Length
                txtLog.ScrollToCaret()

                logForm.ShowDialog()
            Else
                MessageBox.Show("No log entries found.", "Log Viewer", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If

        Catch ex As Exception
            logger.Error("Failed to open log viewer", ex)
            MessageBox.Show($"Error opening log viewer: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Async Function TestFtpConnection() As Task(Of Boolean)
        Try
            logger.Info("Testing FTP connection...")
            Dim host As String = ""
            Dim port As Integer = 21

            Dim serverText As String = If(txtFtpServer?.Text, "")
            Dim usernameText As String = If(txtFtpUsername?.Text, "")
            Dim passwordText As String = If(txtFtpPassword?.Text, "")

            ' Parse FTP URL to extract host and port
            ParseFtpUrl(serverText, host, port)
            logger.Debug($"Parsed server - Host: {host}, Port: {port}")

            ' Log connection attempt (without password)
            logger.Info($"Attempting to connect to {host}:{port} with username: {usernameText}")
            logger.Debug($"Password length: {If(String.IsNullOrEmpty(passwordText), 0, passwordText.Length)} characters")

            Using client As New AsyncFtpClient()
                ' Set connection properties separately to avoid parameter confusion
                client.Host = host
                client.Port = port
                client.Credentials = New System.Net.NetworkCredential(usernameText, passwordText)

                logger.Debug("Configuring FTP client...")
                client.Config.ConnectTimeout = 10000 ' 10 seconds timeout
                client.Config.DataConnectionType = FtpDataConnectionType.PASV

                ' Add compatibility settings for problematic FTP servers
                client.Config.PassiveMaxAttempts = 3
                client.Config.DataConnectionConnectTimeout = 10000
                client.Config.DataConnectionReadTimeout = 10000

                logger.Debug("Attempting AutoConnect...")
                Await client.AutoConnect()

                Dim isConnected As Boolean = client.IsConnected
                logger.Info($"Connection result: {If(isConnected, "SUCCESS", "FAILED")}")

                If isConnected Then
                    logger.Debug("Testing directory listing...")

                    ' Try PASV mode first
                    Dim listingSuccessful As Boolean = False
                    Try
                        Dim listing = Await client.GetListing("/")
                        logger.Debug($"Directory listing successful with PASV - Found {listing.Length} items")
                        listingSuccessful = True
                    Catch pasvEx As FtpException When pasvEx.Message.Contains("PASV")
                        logger.Warning("PASV mode failed, will try EPSV mode", pasvEx)
                        ' Don't use await in catch - handle it after
                    Catch listEx As Exception
                        logger.Warning("Directory listing failed with PASV", listEx)
                    End Try

                    ' If PASV failed, try EPSV
                    If Not listingSuccessful Then
                        Try
                            client.Config.DataConnectionType = FtpDataConnectionType.EPSV
                            Dim listing2 = Await client.GetListing("/")
                            logger.Debug($"Directory listing successful with EPSV - Found {listing2.Length} items")
                            listingSuccessful = True
                        Catch epsvEx As Exception
                            logger.Warning("EPSV mode also failed, will try PORT mode", epsvEx)
                        End Try
                    End If

                    ' If EPSV also failed, try PORT
                    If Not listingSuccessful Then
                        Try
                            client.Config.DataConnectionType = FtpDataConnectionType.PORT
                            Dim listing3 = Await client.GetListing("/")
                            logger.Debug($"Directory listing successful with PORT - Found {listing3.Length} items")
                            listingSuccessful = True
                        Catch portEx As Exception
                            logger.Warning("All data connection modes failed", portEx)
                        End Try
                    End If

                    If Not listingSuccessful Then
                        logger.Warning("Directory listing failed with all connection modes, but connection was successful")
                    End If

                    logger.Debug("Disconnecting from FTP server...")
                    Await client.Disconnect()
                    logger.Info("Successfully disconnected from FTP server")
                End If

                Return isConnected
            End Using
        Catch ex As Exception
            logger.Error($"FTP connection test failed", ex)
            Return False
        End Try
    End Function

    Private Sub rbDirection_CheckedChanged(sender As Object, e As EventArgs) Handles rbLocalToRemote.CheckedChanged, rbRemoteToLocal.CheckedChanged
        UpdateSyncDirectionLabel()

        ' Only save if form is fully loaded
        If Not isFormLoading Then
            SaveConfiguration()
        End If
    End Sub

    Private Sub UpdateSyncDirectionLabel()
        If rbLocalToRemote IsNot Nothing AndAlso rbRemoteToLocal IsNot Nothing AndAlso lblSyncDirection IsNot Nothing Then
            If rbLocalToRemote.Checked Then
                lblSyncDirection.Text = "Local → Remote"
                lblSyncDirection.ForeColor = Color.Blue
            Else
                lblSyncDirection.Text = "Remote → Local"
                lblSyncDirection.ForeColor = Color.DarkGreen
            End If
        End If
    End Sub

    Private Sub btnSync_Click(sender As Object, e As EventArgs) Handles btnSync.Click
        If syncInProgress Then
            ' Cancel sync
            If cancelTokenSource IsNot Nothing Then
                cancelTokenSource.Cancel()
            End If
            Return
        End If

        If Not ValidateInputs() Then
            Return
        End If

        SaveConfiguration()
        StartSync()
    End Sub

    Private Function ValidateInputs() As Boolean
        Dim serverText As String = If(txtFtpServer?.Text, "")
        Dim usernameText As String = If(txtFtpUsername?.Text, "")
        Dim localFolderText As String = If(txtLocalFolder?.Text, "")

        If String.IsNullOrWhiteSpace(serverText) Then
            MessageBox.Show("Please enter FTP server address." & vbCrLf & vbCrLf &
                          "Examples:" & vbCrLf &
                          "• 192.168.1.100" & vbCrLf &
                          "• ftp.example.com:2121" & vbCrLf &
                          "• ftp://192.168.31.132:2122",
                          "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            If txtFtpServer IsNot Nothing Then
                txtFtpServer.Focus()
            End If
            Return False
        End If

        If String.IsNullOrWhiteSpace(usernameText) Then
            MessageBox.Show("Please enter FTP username.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            If txtFtpUsername IsNot Nothing Then
                txtFtpUsername.Focus()
            End If
            Return False
        End If

        If String.IsNullOrWhiteSpace(localFolderText) Then
            MessageBox.Show("Please select local folder.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            If btnBrowseLocal IsNot Nothing Then
                btnBrowseLocal.Focus()
            End If
            Return False
        End If

        If Not Directory.Exists(localFolderText) Then
            MessageBox.Show("Selected local folder does not exist.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            If btnBrowseLocal IsNot Nothing Then
                btnBrowseLocal.Focus()
            End If
            Return False
        End If

        Return True
    End Function

    Private Sub StartSync()
        Dim syncDirection As String = If(rbLocalToRemote?.Checked = True, "Local to Remote", "Remote to Local")
        logger.Info($"Starting synchronization - Direction: {syncDirection}")
        syncInProgress = True
        If btnSync IsNot Nothing Then
            btnSync.Text = "Cancel Sync"
            btnSync.BackColor = Color.IndianRed
        End If
        If progressBar IsNot Nothing Then
            progressBar.Value = 0
            progressBar.Visible = True
        End If
        If lblProgress IsNot Nothing Then
            lblProgress.Visible = True
            lblProgress.Text = "Preparing sync..."
        End If
        If lblStatus IsNot Nothing Then
            lblStatus.Text = "Synchronization in progress..."
            lblStatus.ForeColor = Color.Blue
        End If

        cancelTokenSource = New Threading.CancellationTokenSource()

        Task.Run(Async Function()
                     Try
                         If rbLocalToRemote?.Checked = True Then
                             logger.Info("Starting Local to Remote synchronization")
                             Await SyncLocalToRemote(cancelTokenSource.Token)
                         Else
                             logger.Info("Starting Remote to Local synchronization")
                             Await SyncRemoteToLocal(cancelTokenSource.Token)
                         End If

                         logger.Info("Synchronization completed successfully")
                         Me.Invoke(Sub()
                                       If lblStatus IsNot Nothing Then
                                           lblStatus.Text = "Synchronization completed successfully!"
                                           lblStatus.ForeColor = Color.Green
                                       End If
                                       MessageBox.Show("Synchronization completed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                   End Sub)
                     Catch ex As OperationCanceledException
                         logger.Warning("Synchronization was cancelled by user")
                         Me.Invoke(Sub()
                                       If lblStatus IsNot Nothing Then
                                           lblStatus.Text = "Synchronization cancelled."
                                           lblStatus.ForeColor = Color.Orange
                                       End If
                                   End Sub)
                     Catch ex As Exception
                         logger.Error("Synchronization failed", ex)
                         Me.Invoke(Sub()
                                       If lblStatus IsNot Nothing Then
                                           lblStatus.Text = "Synchronization failed!"
                                           lblStatus.ForeColor = Color.Red
                                       End If
                                       MessageBox.Show($"Synchronization error: {ex.Message}" & vbCrLf & vbCrLf & "Check logs for detailed information.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                                   End Sub)
                     Finally
                         logger.Debug("Cleaning up synchronization UI state")
                         Me.Invoke(Sub()
                                       syncInProgress = False
                                       If btnSync IsNot Nothing Then
                                           btnSync.Text = "Start Sync"
                                           btnSync.BackColor = Color.LimeGreen
                                       End If
                                       If progressBar IsNot Nothing Then
                                           progressBar.Visible = False
                                       End If
                                       If lblProgress IsNot Nothing Then
                                           lblProgress.Visible = False
                                       End If
                                   End Sub)
                     End Try
                 End Function)
    End Sub

    ' Method to parse FTP URL and extract host and port
    Private Sub ParseFtpUrl(serverInput As String, ByRef host As String, ByRef port As Integer)
        Try
            logger.Debug($"Parsing FTP URL: '{serverInput}'")

            If String.IsNullOrWhiteSpace(serverInput) Then
                host = ""
                port = 21
                logger.Warning("Server input is empty or whitespace")
                Return
            End If

            ' Remove leading/trailing spaces
            serverInput = serverInput.Trim()

            ' If it starts with ftp://, parse as URL
            If serverInput.ToLower().StartsWith("ftp://") Then
                logger.Debug("Parsing as FTP URL")
                Dim uri As New Uri(serverInput)
                host = uri.Host
                port = If(uri.Port = -1, 21, uri.Port)
                logger.Debug($"URL parsed - Host: {host}, Port: {port}")
            Else
                ' Check if it contains a port (host:port format)
                If serverInput.Contains(":"c) Then
                    logger.Debug("Parsing as host:port format")
                    Dim parts() As String = serverInput.Split(":"c)
                    If parts.Length = 2 Then
                        host = parts(0).Trim()
                        If Not Integer.TryParse(parts(1).Trim(), port) Then
                            port = 21 ' Default if port parsing fails
                            logger.Warning($"Failed to parse port '{parts(1)}', using default port 21")
                        End If
                        logger.Debug($"Host:Port parsed - Host: {host}, Port: {port}")
                    Else
                        host = serverInput
                        port = 21
                        logger.Warning($"Invalid host:port format, using as hostname with default port")
                    End If
                Else
                    ' Just a hostname or IP
                    logger.Debug("Parsing as plain hostname/IP")
                    host = serverInput
                    port = 21
                End If
            End If

            ' Validate host is not empty
            If String.IsNullOrWhiteSpace(host) Then
                logger.Error("Parsed host is empty")
                Throw New ArgumentException("Invalid server address")
            End If

            logger.Info($"Successfully parsed server - Host: {host}, Port: {port}")

        Catch ex As Exception
            ' If parsing fails, try to use as hostname
            logger.Error($"URL parsing failed for '{serverInput}', using as hostname with default port", ex)
            host = serverInput
            port = 21
        End Try
    End Sub

    Private Async Function SyncLocalToRemote(cancellationToken As Threading.CancellationToken) As Task
        Dim host As String = ""
        Dim port As Integer = 21

        Dim serverText As String = If(txtFtpServer?.Text, "")
        Dim usernameText As String = If(txtFtpUsername?.Text, "")
        Dim passwordText As String = If(txtFtpPassword?.Text, "")
        Dim localFolderText As String = If(txtLocalFolder?.Text, "")
        Dim remoteFolderText As String = If(txtRemoteFolder?.Text, "")

        ' Parse FTP URL to extract host and port
        ParseFtpUrl(serverText, host, port)
        logger.Info($"Starting Local to Remote sync - Target: {host}:{port}")

        Using client As New AsyncFtpClient()
            ' Set connection properties separately
            client.Host = host
            client.Port = port
            client.Credentials = New System.Net.NetworkCredential(usernameText, passwordText)

            client.Config.ConnectTimeout = 30000 ' 30 seconds timeout
            client.Config.DataConnectionType = FtpDataConnectionType.PASV
            logger.Debug("Connecting to FTP server for sync...")
            Await client.AutoConnect(cancellationToken)
            logger.Info("Successfully connected to FTP server for sync")

            ' Ensure remote directory exists
            If Not String.IsNullOrEmpty(remoteFolderText) Then
                logger.Debug($"Creating remote directory: {remoteFolderText}")
                Await client.CreateDirectory(remoteFolderText, True, cancellationToken)
                logger.Info($"Remote directory ensured: {remoteFolderText}")
            End If

            logger.Debug($"Scanning local directory: {localFolderText}")
            Dim localFiles As String() = Directory.GetFiles(localFolderText, "*", SearchOption.AllDirectories)
            Dim totalFiles As Integer = localFiles.Length
            logger.Info($"Found {totalFiles} files to upload")

            If totalFiles = 0 Then
                logger.Warning("No files found in local directory")
                Me.Invoke(Sub()
                              If lblProgress IsNot Nothing Then
                                  lblProgress.Text = "No files to upload"
                              End If
                          End Sub)
                Return
            End If

            Dim processedFiles As Integer = 0
            Dim successCount As Integer = 0
            Dim errorCount As Integer = 0

            For Each localFile As String In localFiles
                If cancellationToken.IsCancellationRequested Then
                    logger.Warning("Upload cancelled by user")
                    Throw New OperationCanceledException()
                End If

                Try
                    Dim relativePath As String = Path.GetRelativePath(localFolderText, localFile)
                    Dim remotePath As String

                    If String.IsNullOrEmpty(remoteFolderText) Then
                        remotePath = relativePath.Replace("\"c, "/"c)
                    Else
                        remotePath = $"{remoteFolderText.TrimEnd("/"c)}/{relativePath.Replace("\"c, "/"c)}"
                    End If

                    logger.Debug($"Uploading file {processedFiles + 1}/{totalFiles}: {localFile}")
                    Me.Invoke(Sub()
                                  If lblProgress IsNot Nothing Then
                                      lblProgress.Text = $"Uploading: {Path.GetFileName(localFile)} ({processedFiles + 1}/{totalFiles})"
                                  End If
                                  If progressBar IsNot Nothing Then
                                      progressBar.Value = CInt((processedFiles / totalFiles) * 100)
                                  End If
                              End Sub)

                    ' Create remote directory structure if needed
                    Dim remoteDir As String = remotePath.Substring(0, remotePath.LastIndexOf("/"c))
                    If Not String.IsNullOrEmpty(remoteDir) Then
                        Await client.CreateDirectory(remoteDir, True, cancellationToken)
                    End If

                    ' Upload file with FluentFTP (replaces existing files)
                    Await client.UploadFile(localFile, remotePath, FtpRemoteExists.Overwrite, True, token:=cancellationToken)
                    successCount += 1
                    logger.Debug($"Successfully uploaded: {remotePath}")

                Catch ex As Exception When Not TypeOf ex Is OperationCanceledException
                    errorCount += 1
                    logger.Error($"Failed to upload {localFile}", ex)
                End Try

                processedFiles += 1
            Next

            logger.Info($"Disconnecting from FTP server...")
            Await client.Disconnect(cancellationToken)
            logger.Info($"Upload completed - Success: {successCount}, Errors: {errorCount}, Total: {processedFiles}")

            Me.Invoke(Sub()
                          If progressBar IsNot Nothing Then
                              progressBar.Value = 100
                          End If
                          If lblProgress IsNot Nothing Then
                              lblProgress.Text = $"Completed: {successCount} uploaded, {errorCount} errors"
                          End If
                      End Sub)
        End Using
    End Function

    Private Async Function SyncRemoteToLocal(cancellationToken As Threading.CancellationToken) As Task
        Dim host As String = ""
        Dim port As Integer = 21

        Dim serverText As String = If(txtFtpServer?.Text, "")
        Dim usernameText As String = If(txtFtpUsername?.Text, "")
        Dim passwordText As String = If(txtFtpPassword?.Text, "")
        Dim localFolderText As String = If(txtLocalFolder?.Text, "")
        Dim remoteFolderText As String = If(txtRemoteFolder?.Text, "")

        ' Parse FTP URL to extract host and port
        ParseFtpUrl(serverText, host, port)
        logger.Info($"Starting Remote to Local sync - Source: {host}:{port}")

        Using client As New AsyncFtpClient()
            ' Set connection properties separately
            client.Host = host
            client.Port = port
            client.Credentials = New System.Net.NetworkCredential(usernameText, passwordText)

            client.Config.ConnectTimeout = 30000 ' 30 seconds timeout
            client.Config.DataConnectionConnectTimeout = 15000
            client.Config.DataConnectionReadTimeout = 15000

            ' Try different approaches for problematic FTP servers
            Dim connectionStrategies() As Action = {
                Sub()
                    ' Strategy 1: Extended Passive with Auto mode
                    client.Config.DataConnectionType = FtpDataConnectionType.EPSV
                    client.Config.PassiveMaxAttempts = 1
                End Sub,
                Sub()
                    ' Strategy 2: Regular Passive with compatibility settings
                    client.Config.DataConnectionType = FtpDataConnectionType.PASV
                    client.Config.PassiveMaxAttempts = 1
                    client.Config.ValidateAnyCertificate = True
                End Sub,
                Sub()
                    ' Strategy 3: Auto detection
                    client.Config.DataConnectionType = FtpDataConnectionType.AutoActive
                    client.Config.PassiveMaxAttempts = 1
                End Sub,
                Sub()
                    ' Strategy 4: Simple connection without data operations
                    client.Config.DataConnectionType = FtpDataConnectionType.PASV
                    client.Config.PassiveMaxAttempts = 3
                End Sub
            }

            Dim connected As Boolean = False
            Dim workingStrategy As Integer = -1

            ' Try each strategy
            For i As Integer = 0 To connectionStrategies.Length - 1
                Try
                    logger.Debug($"Trying connection strategy {i + 1}...")
                    connectionStrategies(i)()

                    Await client.AutoConnect(cancellationToken)

                    If client.IsConnected Then
                        logger.Info($"Successfully connected using strategy {i + 1}")
                        connected = True
                        workingStrategy = i
                        Exit For
                    End If

                Catch ex As Exception
                    logger.Warning($"Strategy {i + 1} failed: {ex.Message}")
                    If client.IsConnected Then
                        Task.Run(Async Function()
                                     Try
                                         Await client.Disconnect(cancellationToken)
                                     Catch
                                     End Try
                                 End Function).Wait()
                    End If
                End Try
            Next

            If Not connected Then
                ' Last resort: Try basic connection without data operations first
                Try
                    logger.Debug("Trying basic connection without data operations...")
                    client.Config.DataConnectionType = FtpDataConnectionType.PASV
                    Await client.AutoConnect(cancellationToken)

                    If client.IsConnected Then
                        logger.Info("Basic connection successful, will attempt file operations")
                        connected = True
                    End If
                Catch ex As Exception
                    logger.Error("All connection strategies failed", ex)
                    Throw New Exception($"Cannot connect to FTP server. All connection methods failed. Server may have compatibility issues.")
                End Try
            End If

            If Not connected Then
                Throw New Exception("Failed to establish FTP connection with any method")
            End If

            ' Try to get directory listing with different approaches
            Dim remoteDirectory As String = If(String.IsNullOrEmpty(remoteFolderText), "/", remoteFolderText)
            Dim remoteFiles As New List(Of FtpListItem)()
            Dim listingSuccessful As Boolean = False

            ' Method 1: Try recursive listing
            Try
                logger.Debug($"Attempting recursive listing of: {remoteDirectory}")
                Dim items = Await client.GetListing(remoteDirectory, FtpListOption.Recursive, cancellationToken)
                remoteFiles.AddRange(items.Where(Function(item) item.Type = FtpObjectType.File))
                listingSuccessful = True
                logger.Info($"Recursive listing successful - found {remoteFiles.Count} files")
            Catch ex As Exception
                logger.Warning($"Recursive listing failed: {ex.Message}")
            End Try

            ' Method 2: Try simple listing if recursive failed
            If Not listingSuccessful Then
                Try
                    logger.Debug($"Attempting simple listing of: {remoteDirectory}")
                    Dim items = Await client.GetListing(remoteDirectory, FtpListOption.Auto, cancellationToken)
                    remoteFiles.AddRange(items.Where(Function(item) item.Type = FtpObjectType.File))
                    listingSuccessful = True
                    logger.Info($"Simple listing successful - found {remoteFiles.Count} files")
                Catch ex As Exception
                    logger.Warning($"Simple listing also failed: {ex.Message}")
                End Try
            End If

            ' Method 3: Manual directory traversal if listing still failed
            If Not listingSuccessful Then
                Try
                    logger.Debug("Attempting manual file discovery...")
                    ' For servers with listing issues, try to work with what we can get
                    Dim basicItems = Await client.GetListing(remoteDirectory, FtpListOption.NoPath, cancellationToken)
                    remoteFiles.AddRange(basicItems.Where(Function(item) item.Type = FtpObjectType.File))
                    listingSuccessful = True
                    logger.Info($"Manual discovery found {remoteFiles.Count} files")
                Catch ex As Exception
                    logger.Error($"All listing methods failed: {ex.Message}")
                    Throw New Exception($"Cannot list files in remote directory '{remoteDirectory}'. Server may not support file listing operations.")
                End Try
            End If

            Dim totalFiles As Integer = remoteFiles.Count
            logger.Info($"Total files to download: {totalFiles}")

            If totalFiles = 0 Then
                logger.Warning("No files found in remote directory")
                Me.Invoke(Sub()
                              If lblProgress IsNot Nothing Then
                                  lblProgress.Text = "No files to download"
                              End If
                          End Sub)
                Return
            End If

            Dim processedFiles As Integer = 0
            Dim successCount As Integer = 0
            Dim errorCount As Integer = 0

            For Each remoteFile As FtpListItem In remoteFiles
                If cancellationToken.IsCancellationRequested Then
                    logger.Warning("Download cancelled by user")
                    Throw New OperationCanceledException()
                End If

                Try
                    Dim relativePath As String = remoteFile.FullName.Replace(remoteDirectory.TrimEnd("/"c) & "/", "").Replace("/"c, "\"c)
                    Dim localPath As String = Path.Combine(localFolderText, relativePath)

                    logger.Debug($"Downloading file {processedFiles + 1}/{totalFiles}: {remoteFile.FullName}")
                    Me.Invoke(Sub()
                                  If lblProgress IsNot Nothing Then
                                      lblProgress.Text = $"Downloading: {Path.GetFileName(remoteFile.Name)} ({processedFiles + 1}/{totalFiles})"
                                  End If
                                  If progressBar IsNot Nothing Then
                                      progressBar.Value = CInt((processedFiles / totalFiles) * 100)
                                  End If
                              End Sub)

                    ' Create local directory if it doesn't exist
                    Dim localDir As String = Path.GetDirectoryName(localPath)
                    If Not Directory.Exists(localDir) Then
                        Directory.CreateDirectory(localDir)
                    End If

                    ' Try download with different transfer modes if needed
                    Dim downloadSuccessful As Boolean = False

                    ' Try binary mode first
                    Try
                        client.Config.DataConnectionType = FtpDataConnectionType.PASV
                        Await client.DownloadFile(localPath, remoteFile.FullName, FtpLocalExists.Overwrite, token:=cancellationToken)
                        downloadSuccessful = True
                    Catch ex As Exception
                        logger.Debug($"PASV download failed for {remoteFile.Name}: {ex.Message}")
                        ' Don't use await in catch - handle it after
                    End Try

                    ' If PASV failed, try AutoActive
                    If Not downloadSuccessful Then
                        Try
                            client.Config.DataConnectionType = FtpDataConnectionType.AutoActive
                            Await client.DownloadFile(localPath, remoteFile.FullName, FtpLocalExists.Overwrite, token:=cancellationToken)
                            downloadSuccessful = True
                        Catch ex2 As Exception
                            logger.Warning($"All download methods failed for {remoteFile.Name}: {ex2.Message}")
                        End Try
                    End If

                    If downloadSuccessful Then
                        successCount += 1
                        logger.Debug($"Successfully downloaded: {localPath}")
                    Else
                        errorCount += 1
                        logger.Error($"Failed to download: {remoteFile.FullName}")
                    End If

                Catch ex As Exception When Not TypeOf ex Is OperationCanceledException
                    errorCount += 1
                    logger.Error($"Error downloading {remoteFile.FullName}", ex)
                End Try

                processedFiles += 1
            Next

            logger.Info($"Disconnecting from FTP server...")
            Await client.Disconnect(cancellationToken)
            logger.Info($"Download completed - Success: {successCount}, Errors: {errorCount}, Total: {processedFiles}")

            Me.Invoke(Sub()
                          If progressBar IsNot Nothing Then
                              progressBar.Value = 100
                          End If
                          If lblProgress IsNot Nothing Then
                              lblProgress.Text = $"Completed: {successCount} downloaded, {errorCount} errors"
                          End If
                      End Sub)
        End Using
    End Function

    Private Sub frmMain_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        If syncInProgress Then
            Dim result As DialogResult = MessageBox.Show("Synchronization is in progress. Do you want to cancel and exit?",
                                                        "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If result = DialogResult.No Then
                e.Cancel = True
                Return
            End If

            If cancelTokenSource IsNot Nothing Then
                cancelTokenSource.Cancel()
            End If
        End If

        SaveConfiguration()
        logger.Info("Application closing")
    End Sub

    Private Sub txtConfiguration_TextChanged(sender As Object, e As EventArgs) Handles txtFtpServer.TextChanged, txtFtpUsername.TextChanged, txtFtpPassword.TextChanged, txtLocalFolder.TextChanged, txtRemoteFolder.TextChanged
        ' Auto-save configuration when text changes (with a small delay to avoid excessive saves)
        ' Only save if the form is fully loaded and configManager is initialized
        If configManager Is Nothing OrElse Not Me.IsHandleCreated OrElse isFormLoading Then
            Return
        End If

        Static saveTimer As Timer
        If saveTimer IsNot Nothing Then
            saveTimer.Stop()
            saveTimer.Dispose()
        End If

        saveTimer = New Timer()
        saveTimer.Interval = 1000 ' 1 second delay
        AddHandler saveTimer.Tick, Sub()
                                       saveTimer.Stop()
                                       saveTimer.Dispose()
                                       If Not isFormLoading Then
                                           SaveConfiguration()
                                       End If
                                   End Sub
        saveTimer.Start()
    End Sub
End Class
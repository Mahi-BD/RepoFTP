﻿Imports System.IO
Imports System.Text

Public Class Logger
    Private Shared _instance As Logger
    Private ReadOnly _logFilePath As String
    Private ReadOnly _lockObject As New Object()

    Public Enum LogLevel
        Debug = 0
        Info = 1
        Warning = 2
        [Error] = 3
        Critical = 4
    End Enum

    Private Sub New()
        Try
            Dim logDirectory As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FTPSync", "Logs")
            If Not Directory.Exists(logDirectory) Then
                Directory.CreateDirectory(logDirectory)
            End If

            Dim fileName As String = $"FTPSync_{DateTime.Now:yyyy-MM-dd}.log"
            _logFilePath = Path.Combine(logDirectory, fileName)
        Catch ex As Exception
            ' If we can't create log directory, use temp folder
            _logFilePath = Path.Combine(Path.GetTempPath(), $"FTPSync_{DateTime.Now:yyyy-MM-dd}.log")
        End Try
    End Sub

    Public Shared ReadOnly Property Instance As Logger
        Get
            If _instance Is Nothing Then
                _instance = New Logger()
            End If
            Return _instance
        End Get
    End Property

    Public Sub WriteLog(level As LogLevel, message As String, Optional ex As Exception = Nothing)
        Try
            SyncLock _lockObject
                Dim logEntry As New StringBuilder()
                logEntry.AppendFormat("[{0:yyyy-MM-dd HH:mm:ss.fff}] ", DateTime.Now)
                logEntry.AppendFormat("[{0}] ", level.ToString().ToUpper())
                logEntry.AppendLine(message)

                If ex IsNot Nothing Then
                    logEntry.AppendLine($"Exception: {ex.GetType().Name}")
                    logEntry.AppendLine($"Message: {ex.Message}")
                    logEntry.AppendLine($"Stack Trace: {ex.StackTrace}")

                    If ex.InnerException IsNot Nothing Then
                        logEntry.AppendLine($"Inner Exception: {ex.InnerException.Message}")
                    End If
                End If

                File.AppendAllText(_logFilePath, logEntry.ToString())

                ' Also write to console for debugging
                Console.WriteLine(logEntry.ToString())
            End SyncLock
        Catch
            ' If logging fails, don't throw an exception
        End Try
    End Sub

    Public Sub Debug(message As String, Optional ex As Exception = Nothing)
        WriteLog(LogLevel.Debug, message, ex)
    End Sub

    Public Sub Info(message As String, Optional ex As Exception = Nothing)
        WriteLog(LogLevel.Info, message, ex)
    End Sub

    Public Sub Warning(message As String, Optional ex As Exception = Nothing)
        WriteLog(LogLevel.Warning, message, ex)
    End Sub

    Public Sub [Error](message As String, Optional ex As Exception = Nothing)
        WriteLog(LogLevel.Error, message, ex)
    End Sub

    Public Sub Critical(message As String, Optional ex As Exception = Nothing)
        WriteLog(LogLevel.Critical, message, ex)
    End Sub

    Public Function GetLogFilePath() As String
        Return _logFilePath
    End Function

    Public Function GetRecentLogs(Optional lineCount As Integer = 50) As String()
        Try
            If File.Exists(_logFilePath) Then
                Dim allLines As String() = File.ReadAllLines(_logFilePath)
                If allLines.Length <= lineCount Then
                    Return allLines
                Else
                    Dim recentLines(lineCount - 1) As String
                    Array.Copy(allLines, allLines.Length - lineCount, recentLines, 0, lineCount)
                    Return recentLines
                End If
            End If
        Catch
            ' If reading fails, return empty array
        End Try
        Return {}
    End Function

    Public Sub ClearOldLogs(Optional daysToKeep As Integer = 7)
        Try
            Dim logDirectory As String = Path.GetDirectoryName(_logFilePath)
            If Directory.Exists(logDirectory) Then
                Dim files As String() = Directory.GetFiles(logDirectory, "FTPSync_*.log")
                Dim cutoffDate As DateTime = DateTime.Now.AddDays(-daysToKeep)

                For Each filePath As String In files
                    Try
                        Dim fileInfo As New FileInfo(filePath)
                        If fileInfo.CreationTime < cutoffDate Then
                            File.Delete(filePath)
                            Info($"Deleted old log file: {Path.GetFileName(filePath)}")
                        End If
                    Catch ex As Exception
                        Warning($"Failed to delete old log file: {Path.GetFileName(filePath)}", ex)
                    End Try
                Next
            End If
        Catch ex As Exception
            Warning("Failed to clean up old log files", ex)
        End Try
    End Sub
End Class